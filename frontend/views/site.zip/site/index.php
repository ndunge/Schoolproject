<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */

$baseUrl = Yii::$app->request->baseUrl;

//echo "working";exit;

$this->title = 'Login';
$error = (isset($error)) ? $error : '';
$url = $baseUrl.'/site/login';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="pure-g">
	<div class="pure-u-1 pure-u-md-1-3">
		<h5>Please enter your login details below</h5> 
		<div id="error" style="color:#F00"><?= $error; ?></div>		
		<form id="file-form" action="<?= $url; ?>" method="POST" onsubmit="return false;" enctype="multipart/form-data">	
			<label>Your Email <span style="color:#F00">*</span></label>
			<div class="input-control text full-size">
				<input name="UserName" type="text" id="UserName" value=""/>
			</div>		
			<label>Password <span style="color:#F00">*</span></label>
			<div class="input-control text full-size">
				<input name="Password" type="password" id="Password"  value=""/>
			</div>	
			<button class="button large-button primary bg-hover-darkRed" onclick="formhash(this.form)">
									<h5 class="align-left">
									<span class="mif-pencil place-left"></span>&nbsp;
									<span class="text-shadow">Login </span></h5>
			</button>	
			<div class="pure-u-1"></div>
			Not Registered? </br>
			<?= Html::a('Register', ['register'], ['class' => 'button success']) ?>
			<div class="pure-u-1"></div>
			<?= Html::a('Forgot Password?', ['forgotpassword'], ['class' => 'link']) ?>
		</form>
	</div>
	<div class="pure-u-1 pure-u-md-2-3" style="padding-left:10px; text-align:justify">
		<p>CUEA was founded on 3 September 1984 in Nairobi Kenya as a Graduate School of Theology, under the name the <strong>Catholic Higher Institute of Eastern Africa (CHIEA)</strong>.   The Institute was founded by the regional ecclesiastical authority   known as Association of Member Episcopal Conferences of Eastern Africa   (AMECEA). The member countries of AMECEA are: Eritrea, Ethiopia, Kenya, Malawi, Sudan, Tanzania, Uganda and Zambia.Initially,   CHIEA offered two-year Licentiate/MA programmes in Theology, as   authorized by the Congregation for Catholic Education, Vatican City (cf.   Prot. N. 821/80/34), effective 2 May 1984. On 3 September of the same   year, it was officially inaugurated by the Right Reverend Bishop Medardo Mazombwe, the then Chairman of AMECEA. On 18 August 1985, it was formally opened by Pope John Paul II. In 1986, the Graduate School of Theology started negotiations with the Commission for Higher Education in Kenya to establish the Catholic University of Eastern Africa (CUEA).</p>
		<p>In 1989, the Institute obtained the &quot;Letter of Interim Authority&quot; as   the first step towards its establishment as a private university. After   three years of intensive negotiations between the Authority of the   Graduate School of Theology (CHIEA) and the Commission for Higher   Education, the Faculty of Arts and Social Sciences was established. The   climax of the negotiations was a granting of the Civil Charter to CHIEA   on 3 November 1992. This marked the birth of the university as a private   institution. The Institute rebranded as the <strong>Catholic University of Eastern Africa</strong>, in 1992.</p>
		<p>In 2002, the Faculties of Science and Commerce were established. Then   in 2003, the Center for Social Justice &amp; ethics was established.   The Faculty of Law was established in 2004, and the School of continuing   professional development in 2009. In 2009, satellite campuses were   established in Eldoret and Kisumu.In April 2013, the university opened a new campus in the I&amp;M Tower, along Kenyatta Avenue, in the Nairobi's central business district. The campus can accommodate up to 500 students.</p>
	</div>
</div>