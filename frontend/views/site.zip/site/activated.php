<ul class="breadcrumbs no-padding-top no-padding-bottom">
		<li><a href="../"><span class="icon mif-home fg-kra-red"></span></a></li>
		<li><a href="../">Home</a></li>
		<li><?= $this->title; ?></li>
</ul>
<div class="pure-u-1"></div>
<div class="pure-g">
	<div class="pure-u-1 pure-u-md-1-3">
	You account has been activated.
	</div>
</div>
