<?php

$identity = Yii::$app->user->identity;

//print_r($identity);
$this->title = 'Dashboard';
?>